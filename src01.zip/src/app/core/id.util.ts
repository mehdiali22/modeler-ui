// تولید Id موقت عددی (منفی) برای رکوردهای جدید قبل از ذخیره در DB
const KEY = 'modeler:v3:tmpId';

export function nextTempId(): number
{
  const raw = localStorage.getItem(KEY);
  let v = raw ? parseInt(raw, 10) : -1;

  if (!Number.isFinite(v) || v >= 0) v = -1;

  // قدم بعدی
  localStorage.setItem(KEY, String(v - 1));
  return v;
}
