import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';

import
  {
    ActionDefinition,
    ActorDefinition,
    Artifact,
    Condition,
    EventDefinition,
    EventTriggerLink,
    Fact,
    Process,
    Scenario,
    Stage,
    TriggerDefinition,
  } from '../../../core/types';

import { ProcessApiService } from '../../../core/api/process-api.service';
import { StageApiService } from '../../../core/api/stage-api.service';
import { ArtifactApiService } from '../../../core/api/artifact-api.service';
import { FactApiService } from '../../../core/api/fact-api.service';
import { ConditionApiService } from '../../../core/api/condition-api.service';
import { ActorApiService } from '../../../core/api/actor-api.service';
import { ActionApiService } from '../../../core/api/action-api.service';
import { TriggerApiService } from '../../../core/api/trigger-api.service';
import { EventApiService } from '../../../core/api/event-api.service';
import { ScenarioApiService } from '../../../core/api/scenario-api.service';
import { EventTriggerLinkApiService } from '../../../core/api/event-trigger-link-api.service';

type OpenMode = 'row' | 'decision';

const VALID_COLS = [
  'processes',
  'stages',
  'artifacts',
  'facts',
  'conditions',
  'actors',
  'actions',
  'triggers',
  'events',
  'scenarios',
  'eventTriggerLinks',
] as const;

type ColName = typeof VALID_COLS[number];

function isColName(x: string): x is ColName
{
  return (VALID_COLS as readonly string[]).includes(x);
}

function parseId(s: string | null): number | null
{
  const t = (s ?? '').trim();
  if (!t) return null;
  const n = Number(t);
  return Number.isFinite(n) && n > 0 ? n : null;
}

function keyOfRow(row: any): string
{
  return (
    row?.scenarioKey ??
    row?.triggerKey ??
    row?.eventKey ??
    row?.conditionKey ??
    row?.factKey ??
    row?.artifactKey ??
    row?.actorKey ??
    row?.actionKey ??
    row?.stageKey ??
    row?.processKey ??
    row?.id ??
    '—'
  ) + '';
}

@Component({
  selector: 'app-open-entity',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './open-entity.component.html',
  styleUrls: ['./open-entity.component.scss'],
})
export class OpenEntityComponent
{
  col: ColName | '' = '';
  id: number | null = null;
  decisionId: number | null = null;
  mode: OpenMode = 'row';

  title = '';
  error: string | null = null;
  loading = false;

  jsonText = '';

  // cache for current loaded objects
  private loadedRow: unknown | null = null;
  private loadedScenario: Scenario | null = null; // used for decision mode

  constructor(
    private route: ActivatedRoute,
    private router: Router,

    private processesApi: ProcessApiService,
    private stagesApi: StageApiService,
    private artifactsApi: ArtifactApiService,
    private factsApi: FactApiService,
    private conditionsApi: ConditionApiService,
    private actorsApi: ActorApiService,
    private actionsApi: ActionApiService,
    private triggersApi: TriggerApiService,
    private eventsApi: EventApiService,
    private scenariosApi: ScenarioApiService,
    private linksApi: EventTriggerLinkApiService,
  )
  {
    this.route.queryParamMap.subscribe((q) =>
    {
      const colRaw = (q.get('col') ?? '').trim();
      this.col = isColName(colRaw) ? colRaw : '';
      this.id = parseId(q.get('id'));
      this.decisionId = parseId(q.get('decisionId'));
      this.mode = this.decisionId ? 'decision' : 'row';
      this.load();
    });
  }

  load(): void
  {
    this.error = null;
    this.title = '';
    this.jsonText = '';
    this.loadedRow = null;
    this.loadedScenario = null;

    if (!this.col || !this.id)
    {
      this.error = 'پارامترهای col و id لازم است.';
      return;
    }

    this.loading = true;

    // decision mode only makes sense for scenarios
    if (this.mode === 'decision')
    {
      if (this.col !== 'scenarios')
      {
        this.loading = false;
        this.error = 'decisionId فقط برای scenarios معتبر است.';
        return;
      }

      this.scenariosApi.get(this.id).subscribe({
        next: (scenario) =>
        {
          this.loadedScenario = scenario ?? null;

          if (!scenario)
          {
            this.error = `Scenario با id=${this.id} پیدا نشد.`;
            this.loading = false;
            return;
          }

          const did = this.decisionId;
          const decisions = scenario.decisions ?? [];
          const dec = did ? decisions.find((d) => d?.id === did) : undefined;

          if (!did || !dec)
          {
            this.error = `Decision با id=${this.decisionId ?? '—'} داخل Scenario پیدا نشد.`;
            this.loading = false;
            return;
          }

          this.title = `Open Decision | scenarios/${this.id} :: ${dec?.decisionKey ?? dec?.id}`;
          this.jsonText = JSON.stringify(dec, null, 2);
          this.loading = false;
        },
        error: (err: unknown) =>
        {
          this.error = this.errMsg(err, 'خطا در دریافت Scenario');
          this.loading = false;
        },
      });

      return;
    }

    // row mode
    this.getRowByCol(this.col, this.id).subscribe({
      next: (row) =>
      {
        if (!row)
        {
          this.error = `موردی با id=${this.id} در collection=${this.col} پیدا نشد.`;
          this.loading = false;
          return;
        }

        this.loadedRow = row;
        const key = keyOfRow(row);
        this.title = `Open ${this.col} | ${key}`;
        this.jsonText = JSON.stringify(row, null, 2);
        this.loading = false;
      },
      error: (err: unknown) =>
      {
        this.error = this.errMsg(err, 'خطا در دریافت رکورد');
        this.loading = false;
      },
    });
  }

  save(): void
  {
    this.error = null;

    if (!this.col || !this.id) return;

    let obj: any;
    try
    {
      obj = JSON.parse(this.jsonText);
    } catch
    {
      this.error = 'JSON نامعتبر است.';
      return;
    }

    // decision mode: update whole scenario with modified decision
    if (this.mode === 'decision')
    {
      if (this.col !== 'scenarios')
      {
        this.error = 'decisionId فقط برای scenarios معتبر است.';
        return;
      }
      const sid = this.id;
      const did = this.decisionId;
      if (!did)
      {
        this.error = 'decisionId نامعتبر است.';
        return;
      }

      // ensure we have scenario fresh
      const scenario = this.loadedScenario;
      if (!scenario)
      {
        this.error = 'Scenario لود نشده. Reload بزن.';
        return;
      }

      const decisions = [...(scenario.decisions ?? [])];
      const idx = decisions.findIndex((d) => d?.id === did);
      if (idx < 0)
      {
        this.error = 'Decision دیگر وجود ندارد.';
        return;
      }

      // keep ids stable
      obj.id = did;
      decisions[idx] = obj;

      const updatedScenario: Scenario = {
        ...scenario,
        id: sid,
        decisions,
      };

      const payload: Omit<Scenario, 'id'> = {
        scenarioKey: updatedScenario.scenarioKey,
        stageId: updatedScenario.stageId,
        titleFa: updatedScenario.titleFa,
        description: updatedScenario.description,
        ownerSubdomain: updatedScenario.ownerSubdomain,
        triggerId: updatedScenario.triggerId,
        preconditionIds: updatedScenario.preconditionIds ?? [],
        producedEventIds: updatedScenario.producedEventIds ?? [],
        actions: updatedScenario.actions ?? [],
        factChanges: updatedScenario.factChanges ?? [],
        decisions: updatedScenario.decisions ?? [],
      };

      this.loading = true;
      this.scenariosApi.update(sid, payload).subscribe({
        next: () => this.load(), // reload to show canonical version from server
        error: (err: unknown) =>
        {
          this.error = this.errMsg(err, 'خطا در ذخیره Scenario');
          this.loading = false;
        },
      });

      return;
    }

    // row mode: update that entity
    obj.id = this.id; // keep id stable

    this.loading = true;
    this.updateRowByCol(this.col, this.id, obj).subscribe({
      next: () => this.load(),
      error: (err: unknown) =>
      {
        this.error = this.errMsg(err, 'خطا در ذخیره رکورد');
        this.loading = false;
      },
    });
  }

  copy(): void
  {
    void navigator.clipboard?.writeText(this.jsonText);
  }

  back(): void
  {
    void this.router.navigateByUrl('/');
  }

  // ---------- API routing ----------
  private getRowByCol(col: ColName, id: number)
  {
    switch (col)
    {
      case 'processes': return this.processesApi.get(id);
      case 'stages': return this.stagesApi.get(id);
      case 'artifacts': return this.artifactsApi.get(id);
      case 'facts': return this.factsApi.get(id);
      case 'conditions': return this.conditionsApi.get(id);
      case 'actors': return this.actorsApi.get(id);
      case 'actions': return this.actionsApi.get(id);
      case 'triggers': return this.triggersApi.get(id);
      case 'events': return this.eventsApi.get(id);
      case 'scenarios': return this.scenariosApi.get(id);
      case 'eventTriggerLinks': return this.linksApi.get(id);
    }
  }

  private updateRowByCol(col: ColName, id: number, obj: any)
  {
    switch (col)
    {
      case 'processes': {
        const payload: Omit<Process, 'id'> = {
          processKey: obj.processKey,
          titleFa: obj.titleFa,
          description: obj.description,
          ownerSubdomain: obj.ownerSubdomain,
          order: obj.order,
        };
        return this.processesApi.update(id, payload);
      }

      case 'stages': {
        const payload: Omit<Stage, 'id'> = {
          processId: obj.processId,
          stageKey: obj.stageKey,
          titleFa: obj.titleFa,
          description: obj.description,
          ownerSubdomain: obj.ownerSubdomain,
          order: obj.order,
        };
        return this.stagesApi.update(id, payload);
      }

      case 'artifacts': {
        const payload: Omit<Artifact, 'id'> = {
          artifactKey: obj.artifactKey,
          titleFa: obj.titleFa,
          description: obj.description,
          isChildOfCase: !!obj.isChildOfCase,
        };
        return this.artifactsApi.update(id, payload);
      }

      case 'facts': {
        const payload: Omit<Fact, 'id'> = {
          artifactId: obj.artifactId,
          factKey: obj.factKey,
          valueType: obj.valueType,
          meaning: obj.meaning,
          description: obj.description,
        };
        return this.factsApi.update(id, payload);
      }

      case 'conditions': {
        const payload: Omit<Condition, 'id'> = {
          conditionKey: obj.conditionKey,
          titleFa: obj.titleFa,
          description: obj.description,
          expression: obj.expression,
          factsUsed: obj.factsUsed ?? [],
        };
        return this.conditionsApi.update(id, payload);
      }

      case 'actors': {
        const payload: Omit<ActorDefinition, 'id'> = {
          actorKey: obj.actorKey,
          titleFa: obj.titleFa,
          description: obj.description,
          kind: obj.kind,
        };
        return this.actorsApi.update(id, payload);
      }

      case 'actions': {
        const payload: Omit<ActionDefinition, 'id'> = {
          actionKey: obj.actionKey,
          titleFa: obj.titleFa,
          description: obj.description,
          targetArtifactId: obj.targetArtifactId,
          executorKind: obj.executorKind,
          executorActorId: obj.executorActorId,
          defaultParamsJson: obj.defaultParamsJson,
        };
        return this.actionsApi.update(id, payload);
      }

      case 'triggers': {
        const payload: Omit<TriggerDefinition, 'id'> = {
          triggerKey: obj.triggerKey,
          titleFa: obj.titleFa,
          description: obj.description,
        };
        return this.triggersApi.update(id, payload);
      }

      case 'events': {
        const payload: Omit<EventDefinition, 'id'> = {
          eventKey: obj.eventKey,
          titleFa: obj.titleFa,
          description: obj.description,
        };
        return this.eventsApi.update(id, payload);
      }

      case 'scenarios': {
        const payload: Omit<Scenario, 'id'> = {
          scenarioKey: obj.scenarioKey,
          stageId: obj.stageId,
          titleFa: obj.titleFa,
          description: obj.description,
          ownerSubdomain: obj.ownerSubdomain,
          triggerId: obj.triggerId,
          preconditionIds: obj.preconditionIds ?? [],
          producedEventIds: obj.producedEventIds ?? [],
          actions: obj.actions ?? [],
          factChanges: obj.factChanges ?? [],
          decisions: obj.decisions ?? [],
        };
        return this.scenariosApi.update(id, payload);
      }

      case 'eventTriggerLinks': {
        const payload: Omit<EventTriggerLink, 'id'> = {
          eventId: obj.eventId,
          triggerId: obj.triggerId,
        };
        return this.linksApi.update(id, payload);
      }
    }
  }

  private errMsg(err: unknown, fallback: string): string
  {
    if (typeof err === 'object' && err && 'message' in err && typeof (err as any).message === 'string')
    {
      return (err as any).message;
    }
    return fallback;
  }
}
